using Microsoft.AspNetCore.Mvc;

namespace TestMvcProject.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return Content("Hello from the test MVC project!");
        }
    }
}
